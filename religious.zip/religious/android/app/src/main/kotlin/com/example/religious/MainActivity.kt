package com.example.religious

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
